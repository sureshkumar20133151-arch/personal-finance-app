# SMS Fix — Definitive (June 2026)

## What was found by decompiling app-debug.apk

### Bug 1 — SMSScanModal wrong permission key (CRITICAL)
**File:** `src/context/SMSScanModal.jsx` (or wherever your scan modal is)

The initial `checkPermissions()` call checked:
```js
if (V.messages === "granted")   // ❌ WRONG — "messages" key doesn't exist
```
The plugin `@solimanware/capacitor-sms-reader` returns `{ readSms: "granted" }`.

So every single time: check fails → triggers requestPermissions → user taps Allow → 
BUT the post-request check also used `j.messages === "granted"` first, 
so it only fell through to `j.readSms === "granted"` as a second check.

**Fix:** Use helper `isSmsGranted(result)` that checks all 3 keys:
```js
result?.readSms === 'granted' || result?.messages === 'granted' || result?.READ_SMS === 'granted'
```

### Bug 2 — autoScanSms.js dedup too strict
**File:** `src/context/autoScanSms.js`

Old dedup:
```js
t.date === e.date  // ❌ exact millisecond match
```
SMS timestamps can vary by seconds between reads. Result: same transaction imported many times.

**Fix:** 60-second window:
```js
Math.abs(new Date(t.date) - new Date(e.date)) < 60 * 1000  // ✅
```

### Bug 3 — smsParser missing Indian Bank / Canara "Dr/Cr" patterns
Many Indian bank SMS use format: `Dr Rs 500.00` or `Rs 500.00 Dr`

**Fix:** Added these patterns to DEBIT_PATTERNS and CREDIT_PATTERNS.

### Bug 4 — smsParser accepts non-bank SMS (OTP, promo)  
Parser had no bank keyword guard, so OTPs with amounts were imported.

**Fix:** Added bank keyword filter before regex matching.

---

## Files to replace

| File | Action |
|------|--------|
| `src/context/autoScanSms.js` | Replace entirely |
| `src/context/SMSScanModal.jsx` | Replace entirely (or merge the `isSmsGranted` fix into your existing file) |

---

## Build commands (run in order)

```powershell
npm run build
npx cap copy android
cd android
$env:JAVA_HOME="C:\Program Files\Android\Android Studio\jbr"
.\gradlew.bat assembleDebug
cd ..
Copy-Item android/app/build/outputs/apk/debug/app-debug.apk -Destination . -Force
```

---

## How to verify it's working (Logcat)

Filter tag: `AutoScan` or `SMSScan`

You should see:
```
[AutoScan] checkPermissions: {"readSms":"granted"}
[AutoScan] Raw SMS count: 47
[AutoScan] Parsed financial SMS: 12
[AutoScan] 12 parsed, 8 new unique
[FinanceContext] Auto-imported 8 SMS transactions
```

If you see `Raw SMS count: 0` — your bank SIM is in slot 2. 
The plugin reads SIM 1 by default. Check `getMessages({ minDate, limit: 200, sim: 2 })`.
