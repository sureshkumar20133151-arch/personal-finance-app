// autoScanSms.js — Definitive Fix (June 2026)
// Bug fixed: SMS returned 0 results silently when listener is OFF and SMS works.
// Bug fixed: Dedup by date+amount+type is too strict — added 60-sec window.
// Bug fixed: SMSScanModal uses V.messages (wrong key on initial check).

import { Capacitor } from '@capacitor/core';

const MessageReader = Capacitor.isNativePlatform()
  ? (() => { try { return (window as any).Capacitor.Plugins.MessageReader; } catch { return null; } })()
  : null;

const NotificationListener = Capacitor.isNativePlatform()
  ? (() => { try { return (window as any).Capacitor.Plugins.NotificationListener; } catch { return null; } })()
  : null;

// ─── Regex Patterns ─────────────────────────────────────────────────────────
const DEBIT_PATTERNS = [
  /(?:rs\.?|inr|₹)\s*([\d,]+(?:\.\d{1,2})?)\s*(?:has\s+been\s+)?(?:debited|spent|withdrawn|transferred|paid|deducted|sent)/i,
  /(?:debited|spent|paid|withdrawn|deducted|sent)\s*(?:for|by|of)?\s*(?:rs\.?|inr|₹)\s*([\d,]+(?:\.\d{1,2})?)/i,
  /sent\s*(?:rs\.?|inr|₹)\s*([\d,]+(?:\.\d{1,2})?)\s*to/i,
  // NEW: "Dr Rs 500" pattern used by Indian Bank / Canara
  /dr\.?\s*(?:rs\.?|inr|₹)?\s*([\d,]+(?:\.\d{1,2})?)/i,
  /(?:rs\.?|inr|₹)\s*([\d,]+(?:\.\d{1,2})?)\s*dr/i,
];

const CREDIT_PATTERNS = [
  /(?:rs\.?|inr|₹)\s*([\d,]+(?:\.\d{1,2})?)\s*(?:has\s+been\s+)?(?:credited|deposited|received)/i,
  /(?:credited|deposited|received)\s*(?:for|by|of)?\s*(?:rs\.?|inr|₹)\s*([\d,]+(?:\.\d{1,2})?)/i,
  /(?:sent|transferred|paid)\s+you\s*(?:rs\.?|inr|₹)\s*([\d,]+(?:\.\d{1,2})?)/i,
  // NEW: "Cr Rs 500" pattern
  /cr\.?\s*(?:rs\.?|inr|₹)?\s*([\d,]+(?:\.\d{1,2})?)/i,
  /(?:rs\.?|inr|₹)\s*([\d,]+(?:\.\d{1,2})?)\s*cr/i,
];

const MERCHANT_PATTERN = /(?:at|to|towards|vpa|info|transfer\s+to|paid\s+to)\s+([a-zA-Z0-9\s\-_\.\\*@\/,\(\)]+?)(?:\s+(?:on|via|using|ref|info|balance|date)|[.,]|\s*|$)/gi;
const MERCHANT_ALT_PATTERN = /(?:merchant|ref|txn)\s+(?:name\s+)?([a-zA-Z0-9\s\-_\.\\*@\/,\(\)]{3,25})/gi;

// ─── Helpers ─────────────────────────────────────────────────────────────────
function isValidMerchant(str) {
  if (!str) return false;
  const s = str.trim();
  if (s.length < 2) return false;
  const low = s.toLowerCase();
  if (low.includes('a/c') || low.includes('acct') || low.includes('account') || low.includes('card') || low.includes('ending')) return false;
  const digits = s.replace(/\D/g, '');
  return !(digits.length > 0 && digits.length >= s.length * 0.7);
}

function getBankName(sms) {
  const t = sms.toLowerCase();
  if (t.includes('indian bank') || t.includes('ind bank') || t.includes('indianbank')) return 'Indian Bank';
  if (t.includes('canara') || t.includes('cnrb')) return 'Canara Bank';
  if (t.includes('sbi') || t.includes('state bank') || t.includes('yono')) return 'SBI';
  if (t.includes('hdfc')) return 'HDFC Bank';
  if (t.includes('icici')) return 'ICICI Bank';
  if (t.includes('axis')) return 'Axis Bank';
  if (t.includes('kotak')) return 'Kotak Bank';
  if (t.includes('baroda') || t.includes('bob')) return 'Bank of Baroda';
  if (t.includes('pnb') || t.includes('punjab national')) return 'PNB';
  if (t.includes('paytm') || t.includes('ppbl')) return 'Paytm Bank';
  if (t.includes('airtel') || t.includes('apbl')) return 'Airtel Bank';
  return 'Bank Account';
}

function getAccountEnding(sms) {
  const patterns = [
    /(?:a\/c|acct|account|card|ending)\s*(?:ending)?\s*(?:in|with)?\s*([xX\*]*\d{3,4})/i,
    /ending\s+([xX\*]*\d{3,4})/i,
    /ending\s+in\s+(\d{3,4})/i,
    // NEW: "Ac no XX1234" pattern
    /ac\s*no\.?\s*[xX\*]*(\d{3,4})/i,
    /a\/c\s*[xX\*]*(\d{3,4})/i,
  ];
  for (const p of patterns) {
    const m = sms.match(p);
    if (m && m[1]) {
      const digits = m[1].replace(/\D/g, '');
      if (digits.length >= 3) return digits;
    }
  }
  return null;
}

export function parseSms(body, dateMs) {
  if (!body) return null;
  const low = body.toLowerCase();

  // Skip failed/declined
  if (low.includes('failed') || low.includes('declined') || low.includes('insufficient') ||
      low.includes('unsuccessful') || low.includes('rejected')) return null;

  // Must mention a bank keyword to avoid OTP / promo SMS
  const bankKeywords = ['a/c', 'acct', 'account', 'balance', 'debited', 'credited', 'dr.', 'cr.',
                        'inr', 'rs.', '₹', 'upi', 'neft', 'imps', 'rtgs', 'netbanking', 'atm'];
  if (!bankKeywords.some(k => low.includes(k))) return null;

  let amount = null;
  let type = null;

  for (const p of DEBIT_PATTERNS) {
    const m = body.match(p);
    if (m) {
      const val = (m[1] || m[2] || '').replace(/,/g, '');
      if (val) { amount = parseFloat(val); type = 'expense'; break; }
    }
  }

  if (!amount) {
    for (const p of CREDIT_PATTERNS) {
      const m = body.match(p);
      if (m) {
        const val = (m[1] || m[2] || '').replace(/,/g, '');
        if (val) { amount = parseFloat(val); type = 'income'; break; }
      }
    }
  }

  if (!amount || isNaN(amount) || amount <= 0) return null;

  // Extract merchant
  let merchant = null;
  for (const m of body.matchAll(MERCHANT_PATTERN)) {
    if (m?.[1] && isValidMerchant(m[1])) { merchant = m[1].trim(); break; }
  }
  if (!merchant) {
    for (const m of body.matchAll(MERCHANT_ALT_PATTERN)) {
      if (m?.[1] && isValidMerchant(m[1])) { merchant = m[1].trim(); break; }
    }
  }

  let description = 'Online Transaction';
  if (merchant) {
    merchant = merchant.split('(')[0].trim().replace(/^vpa\s+/i, '').replace(/[.,\s]+$/, '').trim();
    description = merchant;
  }
  description = description.replace(/\s+/g, ' ');
  if (description.length > 30) description = description.substring(0, 27) + '...';

  // Payment mode
  let paymentMode = 'upi';
  if (low.includes('atm') || low.includes('cash withdrawal')) { paymentMode = 'cash'; description = 'ATM Cash Withdrawal'; }
  else if (low.includes('card') || low.includes('debitcard') || low.includes('creditcard') || low.includes('ending in')) paymentMode = 'card';
  else if (low.includes('netbanking') || low.includes('internet banking') || low.includes('imps') || low.includes('neft') || low.includes('rtgs')) paymentMode = 'netbanking';
  else if (low.includes('upi') || low.includes('gpay') || low.includes('phonepe') || low.includes('paytm') || low.includes('amazonpay')) paymentMode = 'upi';

  return {
    amount,
    description,
    type,
    date: dateMs ? new Date(dateMs).toISOString() : new Date().toISOString(),
    paymentMode,
    bankName: getBankName(body),
    accountEnding: getAccountEnding(body),
    rawSms: body,
  };
}

// ─── Permission helpers ───────────────────────────────────────────────────────
async function checkSmsPermission() {
  try {
    if (!MessageReader) return false;
    const r = await MessageReader.checkPermissions();
    console.log('[AutoScan] checkPermissions:', JSON.stringify(r));
    return r?.readSms === 'granted' || r?.messages === 'granted' || r?.READ_SMS === 'granted';
  } catch (e) {
    console.warn('[AutoScan] checkPermissions error:', e);
    return false;
  }
}

async function requestSmsPermission() {
  try {
    if (!MessageReader) return false;
    const r = await MessageReader.requestPermissions();
    console.log('[AutoScan] requestPermissions:', JSON.stringify(r));
    return r?.readSms === 'granted' || r?.messages === 'granted' || r?.READ_SMS === 'granted';
  } catch (e) {
    console.warn('[AutoScan] requestPermissions error:', e);
    return false;
  }
}

// ─── Read SMS inbox ───────────────────────────────────────────────────────────
async function readSmsInbox() {
  const minDate = Date.now() - 30 * 24 * 60 * 60 * 1000;
  try {
    const { messages = [] } = await MessageReader.getMessages({ minDate, limit: 200 });
    console.log('[AutoScan] Raw SMS count:', messages.length);
    const parsed = messages.map(m => parseSms(m.body, parseInt(m.date))).filter(Boolean);
    console.log('[AutoScan] Parsed financial SMS:', parsed.length);
    return parsed;
  } catch (e) {
    console.error('[AutoScan] getMessages failed:', e);
    return [];
  }
}

// ─── Read notifications ───────────────────────────────────────────────────────
async function readNotifications() {
  const minDate = Date.now() - 30 * 24 * 60 * 60 * 1000;
  try {
    const { notifications = [] } = await NotificationListener.getCapturedNotifications({ minDate: String(minDate) });
    console.log('[AutoScan] Raw notification count:', notifications.length);
    const parsed = notifications.map(n => parseSms(n.body, parseInt(n.date))).filter(Boolean);
    console.log('[AutoScan] Parsed financial notifications:', parsed.length);
    return parsed;
  } catch (e) {
    console.warn('[AutoScan] getCapturedNotifications error:', e);
    return [];
  }
}

// ─── Deduplication ───────────────────────────────────────────────────────────
// FIX: Use 60-second window instead of exact date match (SMS timestamps vary by seconds)
function isDuplicate(existingTransactions, candidate) {
  return existingTransactions.some(t => {
    const sameDateWindow = Math.abs(new Date(t.date) - new Date(candidate.date)) < 60 * 1000;
    const sameAmount = Math.abs(t.amount - candidate.amount) < 0.01;
    const sameType = t.type === candidate.type;
    const sameBank = t.bankName === candidate.bankName;
    const sameAccount = t.accountEnding === candidate.accountEnding;
    return sameDateWindow && sameAmount && sameType && sameBank && sameAccount;
  });
}

// ─── Main export ─────────────────────────────────────────────────────────────
export async function autoScanTransactions(existingTransactions = []) {
  if (!Capacitor.isNativePlatform()) return { newTransactions: [], needsSetup: false };

  const allParsed = [];
  let smsBlocked = false;

  // ── SMS path ──
  try {
    let granted = await checkSmsPermission();
    if (!granted) {
      console.log('[AutoScan] SMS not granted — requesting...');
      granted = await requestSmsPermission();
    }
    if (granted) {
      const smsTxns = await readSmsInbox();
      smsTxns.forEach(t => allParsed.push(t));
      console.log('[AutoScan] SMS path total:', allParsed.length);
    } else {
      smsBlocked = true;
      console.log('[AutoScan] SMS permission denied after request');
    }
  } catch (e) {
    console.warn('[AutoScan] SMS path error:', e);
    smsBlocked = true;
  }

  // ── Notification Listener path ──
  try {
    if (!NotificationListener) throw new Error('NotificationListener plugin missing');
    const { enabled } = await NotificationListener.isListenerEnabled();
    console.log('[AutoScan] Notification listener enabled:', enabled);
    if (enabled) {
      const notifTxns = await readNotifications();
      notifTxns.forEach(t => allParsed.push(t));
      if (notifTxns.length === 0 && smsBlocked) {
        // Listener active but no data yet — first launch
        return { newTransactions: [], needsSetup: false };
      }
    } else if (smsBlocked) {
      // SMS blocked + listener not set up → show setup UI
      return { newTransactions: [], needsSetup: true };
    }
  } catch (e) {
    console.warn('[AutoScan] Notification listener error:', e);
    if (smsBlocked && allParsed.length === 0) {
      return { newTransactions: [], needsSetup: true };
    }
  }

  if (allParsed.length === 0) return { newTransactions: [], needsSetup: false };

  const newTransactions = allParsed.filter(t => !isDuplicate(existingTransactions, t));
  console.log(`[AutoScan] ${allParsed.length} parsed, ${newTransactions.length} new unique`);
  return { newTransactions, needsSetup: false };
}
