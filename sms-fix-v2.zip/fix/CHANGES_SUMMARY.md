# EXACT FIXES — 3 CHANGES ONLY

## Why it wasn't working

| Problem | What happened | Fix |
|---------|--------------|-----|
| Dashboard shows no bank balance | `bankBalance` not pulled from context in Dashboard.jsx | Add 4 variables to destructure + paste balance JSX |
| SMS not reading | `autoScanTransactions` only **checked** permission, never **asked** | Replace `autoScanSms.js` with new version |
| 0 transactions found | Notification Listener was ON but no bank notifications captured yet | Fixed fallback logic — no longer shows setup when listener is on but empty |

---

## FILE 1 — Dashboard.jsx

Find this destructure (the `Na()` call in the `Yv` function):
```js
const { transactions: S = [], formatMoney: e, categories: t = [],
        loans: i = [], recurring: r = [], salaryDate: s,
        monthlyBudget: o, initialBankBalance: c = 0,
        initialCashBalance: d = 0, rescanTransactions: u } = Na();
```

ADD four more:
```js
const { transactions: S = [], formatMoney: e, categories: t = [],
        loans: i = [], recurring: r = [], salaryDate: s,
        monthlyBudget: o, initialBankBalance: c = 0,
        initialCashBalance: d = 0, rescanTransactions: u,
        bankBalance,            // ← ADD THIS
        cashBalance,            // ← ADD THIS
        totalBalance,           // ← ADD THIS
        bankAccountBalances,    // ← ADD THIS
      } = Na();
```

Then in the JSX, find `<div id="tour-kpi-cards"` and paste the balance cards
JSX from `FIX_1_Dashboard_paste_instructions.jsx` directly above it.

---

## FILE 2 — autoScanSms.js

**Replace the entire file** with `autoScanSms.js` from this folder.

Key change: `autoScanTransactions` now returns `{ newTransactions, needsSetup }`
instead of just an array.

---

## FILE 3 — FinanceContext.jsx

Find the boot function (the `$ = async se =>` block inside `useEffect`).

Replace only the **inner body** of that function with the code from
`FIX_2_3_FinanceContext_changes.jsx`.

The change:
- OLD: `const De = await Vb(se.transactions || []);`  → De is an array
- NEW: `const { newTransactions: De, needsSetup } = await autoScanTransactions(...);`
       Then dispatch `sms_needs_setup` event if needsSetup is true

---

## FILE 4 — App.jsx (or your root component)

Add the SmsSetupGuide listener from `FIX_2_3_FinanceContext_changes.jsx`.

---

## Build commands

```bash
npm run build
npx cap copy android
# then build APK in Android Studio
```

---

## Test checklist after install

1. Fresh install → Android SMS permission dialog should appear ✅
2. Grant permission → transactions load on Dashboard ✅
3. Deny SMS → SmsSetupGuide modal appears (enable notification listener) ✅
4. Dashboard shows: Bank Balance | Cash in Hand | Total  ✅
5. Per-bank cards scroll horizontally (Indian Bank, SBI, etc.) ✅
