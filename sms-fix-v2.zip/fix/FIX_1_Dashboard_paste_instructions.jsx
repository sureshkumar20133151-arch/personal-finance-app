// ─────────────────────────────────────────────────────────────────────────────
//  PASTE THIS INSIDE YOUR Dashboard.jsx (Yv component)
//
//  Step 1: Find this line in Dashboard.jsx:
//    const { transactions: S = [], formatMoney: e, categories: t = [],
//            loans: i = [], recurring: r = [], salaryDate: s,
//            monthlyBudget: o, initialBankBalance: c = 0,
//            initialCashBalance: d = 0, rescanTransactions: u } = Na();
//
//  Step 2: ADD these 4 to the destructure:
//    bankBalance, cashBalance, totalBalance, bankAccountBalances
//
//  So it becomes:
// ─────────────────────────────────────────────────────────────────────────────

/*
  const {
    transactions: S = [],
    formatMoney: e,
    categories: t = [],
    loans: i = [],
    recurring: r = [],
    salaryDate: s,
    monthlyBudget: o,
    initialBankBalance: c = 0,
    initialCashBalance: d = 0,
    rescanTransactions: u,
    bankBalance,          // ← ADD
    cashBalance,          // ← ADD
    totalBalance,         // ← ADD
    bankAccountBalances,  // ← ADD
  } = Na();
*/

// ─────────────────────────────────────────────────────────────────────────────
//  Step 3: Find where your Dashboard JSX starts (the first return's opening div)
//  and paste the BankBalanceSection component JSX right after the page header:
//
//  Find: <div id="tour-kpi-cards"  (or the KPI cards grid)
//  Paste THIS above it:
// ─────────────────────────────────────────────────────────────────────────────

/*
<div className="space-y-3 mb-6">
  {/* ── Summary row ──────────────────────────────────── */}
  <div className="grid grid-cols-3 gap-3">
    <div className="rounded-2xl border bg-card p-4 shadow-sm text-center">
      <p className="text-[10px] uppercase font-bold text-muted-foreground tracking-wider mb-1">
        Bank Balance
      </p>
      <p className={`text-lg font-bold ${bankBalance >= 0 ? "text-blue-600 dark:text-blue-400" : "text-red-500"}`}>
        {e(bankBalance)}
      </p>
    </div>
    <div className="rounded-2xl border bg-card p-4 shadow-sm text-center">
      <p className="text-[10px] uppercase font-bold text-muted-foreground tracking-wider mb-1">
        Cash in Hand
      </p>
      <p className={`text-lg font-bold ${cashBalance >= 0 ? "text-green-600 dark:text-green-400" : "text-red-500"}`}>
        {e(cashBalance)}
      </p>
    </div>
    <div className="rounded-2xl border bg-primary/10 border-primary/20 p-4 shadow-sm text-center">
      <p className="text-[10px] uppercase font-bold text-primary/70 tracking-wider mb-1">Total</p>
      <p className={`text-lg font-bold ${totalBalance >= 0 ? "text-primary" : "text-red-500"}`}>
        {e(totalBalance)}
      </p>
    </div>
  </div>

  {/* ── Per-bank scrollable cards ───────────────────── */}
  {bankAccountBalances && bankAccountBalances.length > 0 && (
    <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-none snap-x">
      {bankAccountBalances.map((bank, i) => {
        const COLORS = {
          "SBI": "#0284c7", "HDFC Bank": "#dc2626", "ICICI Bank": "#ea580c",
          "Indian Bank": "#1d4ed8", "Canara Bank": "#0d9488", "Axis Bank": "#7c3aed",
          "Kotak Bank": "#ca8a04", "GPay": "#4285f4", "PhonePe": "#5f259f",
        };
        const EMOJI = {
          "SBI": "🔷", "HDFC Bank": "🔴", "ICICI Bank": "🟠",
          "Indian Bank": "🔵", "Canara Bank": "🟢", "Axis Bank": "🟣",
          "Kotak Bank": "🟡", "GPay": "🎯", "PhonePe": "💜",
        };
        const color = COLORS[bank.bankName] || "#6366f1";
        return (
          <div
            key={`${bank.bankName}_${bank.accountEnding}_${i}`}
            className="flex-shrink-0 w-48 rounded-2xl border p-4 shadow-sm snap-start"
            style={{ background: `linear-gradient(135deg, ${color}18, ${color}08)` }}
          >
            <div className="flex justify-between items-start mb-3">
              <div>
                <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">
                  {bank.bankName}
                </p>
                <p className="text-xs text-muted-foreground/70 mt-0.5">
                  A/c •••• {bank.accountEnding}
                </p>
              </div>
              <span className="text-base">{EMOJI[bank.bankName] || "🏦"}</span>
            </div>
            <p
              className="text-xl font-bold"
              style={{ color: bank.balance >= 0 ? color : "#ef4444" }}
            >
              {e(bank.balance)}
            </p>
            <p className="text-[9px] text-muted-foreground mt-1">
              {bank.transactionCount} transactions
            </p>
          </div>
        );
      })}
    </div>
  )}
</div>
*/
