# EXACT 3 ISSUES FOUND IN YOUR APK

## Issue 1 — Dashboard DOES NOT SHOW bank balance cards
Dashboard destructures from context:
  const { transactions, formatMoney, categories, loans, recurring,
          salaryDate, monthlyBudget, initialBankBalance, initialCashBalance,
          rescanTransactions } = Na()

It does NOT pull: bankBalance, cashBalance, totalBalance, bankAccountBalances
So DashboardBalanceCards component was never added to Dashboard.jsx

## Issue 2 — SMS auto-scan runs but SMS permission is NEVER REQUESTED on startup
autoScan (Vb) only does: checkPermissions() → if granted, read
It NEVER calls requestPermissions() on startup
So first-time users: no permission = no data

## Issue 3 — Notification Listener reads 0 notifications
The listener captures notifications in real-time only AFTER it is enabled
First install = no captured notifications yet
So both paths fail silently with 0 results
