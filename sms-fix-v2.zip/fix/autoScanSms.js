// ─────────────────────────────────────────────────────────────────────────────
//  autoScanSms.js  ← REPLACE your existing file with this
//
//  Fixes:
//   ✅ Fix 2: Now REQUESTS SMS permission on first run (not just checks)
//   ✅ Fix 3: If SMS blocked → shows SmsSetupGuide to user (instead of silent fail)
//   ✅ Notification Listener: reads real captured notifications correctly
// ─────────────────────────────────────────────────────────────────────────────

import { registerPlugin } from "@capacitor/core";
import { parseSms } from "./smsParser";

const MessageReader        = registerPlugin("MessageReader");
const NotificationListener = registerPlugin("NotificationListener");

const SCAN_DAYS = 30;

// De-duplicate check
function isDuplicate(existing = [], tx) {
  return existing.some(
    (e) =>
      e.date          === tx.date &&
      Math.abs(e.amount - tx.amount) < 0.01 &&
      e.type          === tx.type &&
      e.bankName      === tx.bankName &&
      e.accountEnding === tx.accountEnding
  );
}

// ─── Auto-assign category ────────────────────────────────────────────────────
export function autoCategory(description, type, categories = []) {
  const d       = (description || "").toLowerCase();
  const income  = categories.filter((c) => c.type === "income");
  const expense = categories.filter((c) => c.type === "expense");
  const firstExpense = expense[0]?.id || "";
  const firstIncome  = income[0]?.id  || "";

  if (type === "income") {
    if (d.includes("salary")) {
      const cat = income.find((c) => c.name.toLowerCase().includes("salary"));
      return cat ? cat.id : firstIncome;
    }
    const biz = income.find(
      (c) =>
        c.name.toLowerCase().includes("freelance") ||
        c.name.toLowerCase().includes("business")
    );
    return biz ? biz.id : firstIncome;
  }

  const map = [
    { kw: ["zomato","swiggy","food","restaurant","chai","cafe","hotel"],        cw: ["food","dining","coffee"]         },
    { kw: ["petrol","fuel","uber","ola","travel","auto","cab","rapido"],         cw: ["transport","travel","fuel"]       },
    { kw: ["netflix","spotify","prime","movie","cinema","hotstar"],              cw: ["entertainment","sub"]             },
    { kw: ["electricity","recharge","water","broadband","wifi","ebill"],         cw: ["utilities","bill"]                },
    { kw: ["amazon","flipkart","shop","myntra","meesho"],                        cw: ["shopping","clothes"]              },
    { kw: ["doctor","hospital","medicine","pharmacy","clinic"],                  cw: ["health","medical"]                },
  ];
  for (const { kw, cw } of map) {
    if (kw.some((k) => d.includes(k))) {
      const cat = expense.find((c) => cw.some((w) => c.name.toLowerCase().includes(w)));
      if (cat) return cat.id;
    }
  }
  return firstExpense;
}

// ─── Read via SMS ────────────────────────────────────────────────────────────
async function readSms() {
  const minDate = Date.now() - SCAN_DAYS * 24 * 60 * 60 * 1000;
  const { messages = [] } = await MessageReader.getMessages({ minDate, limit: 200 });
  console.log("[AutoScan] Raw SMS count:", messages.length);
  const parsed = messages.map((m) => parseSms(m.body, parseInt(m.date))).filter(Boolean);
  console.log("[AutoScan] Parsed financial SMS:", parsed.length);
  return parsed;
}

// ─── Read via Notification Listener ─────────────────────────────────────────
async function readNotifications() {
  const minDate = Date.now() - SCAN_DAYS * 24 * 60 * 60 * 1000;
  const { notifications = [] } = await NotificationListener.getCapturedNotifications({
    minDate: String(minDate),
  });
  console.log("[AutoScan] Raw notification count:", notifications.length);
  const parsed = notifications.map((n) => parseSms(n.body, parseInt(n.date))).filter(Boolean);
  console.log("[AutoScan] Parsed financial notifications:", parsed.length);
  return parsed;
}

// ─── MAIN: startup auto-scan ─────────────────────────────────────────────────
//
//  Returns: { newTransactions: [], needsSetup: false }
//
//  needsSetup = true means: show the SmsSetupGuide modal to the user
//  newTransactions = array of parsed tx ready to save (de-duped)
//
export async function autoScanTransactions(existingTransactions = []) {
  if (!window.Capacitor?.isNativePlatform()) {
    return { newTransactions: [], needsSetup: false };
  }

  const minDate = Date.now() - SCAN_DAYS * 24 * 60 * 60 * 1000;
  const parsed  = [];

  // ── Try SMS ─────────────────────────────────────────────────────────────
  let smsBlocked = false;
  try {
    // First check
    let perm = await MessageReader.checkPermissions();
    console.log("[AutoScan] SMS permission status:", JSON.stringify(perm));

    // ✅ FIX 2: If not granted → REQUEST (first install will trigger Android dialog)
    if (perm?.messages !== "granted") {
      console.log("[AutoScan] SMS not granted — requesting...");
      try {
        const req = await MessageReader.requestPermissions();
        console.log("[AutoScan] SMS permission result:", JSON.stringify(req));
        if (req?.messages === "granted" || req?.readSms === "granted") {
          perm = { messages: "granted" };
        } else if (Array.isArray(req?.messages)) {
          // Some plugin versions return messages directly
          req.messages.forEach((m) => {
            const tx = parseSms(m.body, parseInt(m.date));
            if (tx) parsed.push(tx);
          });
          const newTxs = parsed.filter((tx) => !isDuplicate(existingTransactions, tx));
          console.log(`[AutoScan] ${parsed.length} parsed, ${newTxs.length} new`);
          return { newTransactions: newTxs, needsSetup: false };
        }
      } catch (e) {
        console.warn("[AutoScan] Permission request failed:", e);
      }
    }

    if (perm?.messages === "granted") {
      const msgs = await readSms();
      msgs.forEach((tx) => parsed.push(tx));
    } else {
      smsBlocked = true;
      console.log("[AutoScan] SMS blocked after request");
    }
  } catch (e) {
    console.warn("[AutoScan] SMS failed:", e);
    smsBlocked = true;
  }

  // ── Try Notification Listener ────────────────────────────────────────────
  if (smsBlocked || parsed.length === 0) {
    try {
      const status = await NotificationListener.isListenerEnabled();
      console.log("[AutoScan] Notification listener enabled:", status?.enabled);

      if (status?.enabled) {
        const notifs = await readNotifications();
        notifs.forEach((tx) => parsed.push(tx));

        // ✅ FIX 3: Listener is ON but 0 notifications — user enabled it but
        // no transactions happened yet. Don't show setup, just return empty.
        if (notifs.length === 0 && smsBlocked) {
          console.log("[AutoScan] Listener enabled but no notifications yet — skip setup");
          return { newTransactions: [], needsSetup: false };
        }
      } else if (smsBlocked) {
        // Both SMS blocked AND listener not enabled → show setup guide
        console.log("[AutoScan] Both SMS and Notification Listener unavailable → needsSetup");
        return { newTransactions: [], needsSetup: true };
      }
    } catch (e) {
      console.warn("[AutoScan] Notification listener failed:", e);
      if (smsBlocked) return { newTransactions: [], needsSetup: true };
    }
  }

  if (parsed.length === 0) return { newTransactions: [], needsSetup: false };

  const newTxs = parsed.filter((tx) => !isDuplicate(existingTransactions, tx));
  console.log(`[AutoScan] ${parsed.length} parsed, ${newTxs.length} new unique transactions`);
  return { newTransactions: newTxs, needsSetup: false };
}

// ─── Foreground rescan (same logic, no needsSetup on rescan) ─────────────────
export async function rescanTransactions(existingTransactions = []) {
  const result = await autoScanTransactions(existingTransactions);
  return result.newTransactions;
}
