// ─────────────────────────────────────────────────────────────────────────────
//  CHANGE IN FinanceContext.jsx — only the boot() function changes
//
//  Find this block in your FinanceContext.jsx (the boot async function):
//
//    const $ = async se => {
//      if (!z) {
//        const De = await Vb(se.transactions || []);
//        if (De.length > 0 && !z) {
//          ... save ...
//        } else i(se);
//        s(!1);
//      }
//    };
//
//  REPLACE the entire boot function with this:
// ─────────────────────────────────────────────────────────────────────────────

/*

  // Boot function — replaces existing $ = async se => { ... }
  const $ = async (se) => {
    if (z) return;

    // ✅ FIX 2+3: autoScanTransactions now returns { newTransactions, needsSetup }
    const { newTransactions: De, needsSetup } = await autoScanTransactions(se.transactions || []);

    if (needsSetup && !z) {
      // Notify app to show SmsSetupGuide
      // We use a custom event so Dashboard/App can show the modal
      window.dispatchEvent(new CustomEvent("sms_needs_setup"));
    }

    if (De.length > 0 && !z) {
      console.log(`[FinanceContext] Auto-imported ${De.length} SMS transactions`);
      const te = De.map((Fe) => ({
        ...Fe,
        id:         ta(),
        categoryId: Gb(Fe.description, Fe.type, se.categories || Cf),
      }));
      const de = { ...se, transactions: [...(se.transactions || []), ...te] };
      c(de);
      i(de);
    } else {
      i(se);
    }
    s(false);
  };

*/

// ─────────────────────────────────────────────────────────────────────────────
//  CHANGE 2: Update import at top of FinanceContext.jsx
//
//  Find:
//    import { autoScanTransactions, autoCategory } from "./autoScanSms";
//
//  It should already be there. If not, add it.
//  The autoScanTransactions function now returns { newTransactions, needsSetup }
//  so the boot function above handles it correctly.
// ─────────────────────────────────────────────────────────────────────────────


// ─────────────────────────────────────────────────────────────────────────────
//  CHANGE 3: In App.jsx or your main layout — listen for sms_needs_setup event
//  and show SmsSetupGuide modal
//
//  Add this in your main App.jsx:
// ─────────────────────────────────────────────────────────────────────────────

/*

import { useEffect, useState } from "react";
import SmsSetupGuide from "./SmsSetupGuide";

function App() {
  const [showSmsSetup, setShowSmsSetup] = useState(false);

  useEffect(() => {
    const handler = () => setShowSmsSetup(true);
    window.addEventListener("sms_needs_setup", handler);
    return () => window.removeEventListener("sms_needs_setup", handler);
  }, []);

  return (
    <>
      {/* your existing app JSX */}
      <SmsSetupGuide
        isOpen={showSmsSetup}
        onClose={() => setShowSmsSetup(false)}
        onDone={() => {
          setShowSmsSetup(false);
          // Optionally trigger a rescan after setup
          window.dispatchEvent(new CustomEvent("sms_rescan"));
        }}
      />
    </>
  );
}

*/
