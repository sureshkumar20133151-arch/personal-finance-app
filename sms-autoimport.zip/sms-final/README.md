# Bank SMS Auto-Import — Integration Guide

## Files in this folder

| File | Purpose |
|------|---------|
| `smsParser.js`         | Parses raw bank SMS → transaction object |
| `autoScanSms.js`       | Runs on startup, de-duplicates, returns new txs |
| `FinanceContext.jsx`   | Drop-in replacement for your context (has SMS built-in) |
| `DashboardBalanceCards.jsx` | Dashboard component showing bank balance |
| `SmsSetupGuide.jsx`    | Modal shown when notification listener needs setup |

---

## Step 1 — Install the SMS plugin

```bash
npm install @solimanware/capacitor-sms-reader
npx cap sync android
```

---

## Step 2 — Drop files into your src/

Copy all 5 files into `src/` (same folder as your existing context).

---

## Step 3 — Fix 2 import paths in FinanceContext.jsx

Open `FinanceContext.jsx` and update these two lines to match your project:

```js
import { db }       from "./firebase";      // your firebase.js
import { useAuth }  from "./AuthContext";   // your auth context
```

---

## Step 4 — Replace your existing FinanceContext

In your `App.jsx` or wherever `FinanceProvider` is used — no change needed,
the export names are identical.

If your old file is named `FinanceContext.jsx`, just overwrite it.

---

## Step 5 — Add balance cards to Dashboard

In your `Dashboard.jsx`, add at the top of the component body:

```jsx
import DashboardBalanceCards from "./DashboardBalanceCards";
```

And in the JSX, paste it where you want the bank balance section:

```jsx
{/* Bank balance summary */}
<DashboardBalanceCards />
```

---

## Step 6 — Add uuid package if not already installed

```bash
npm install uuid
```

---

## That's it.

On first launch:
1. If SMS permission already granted → transactions load automatically
2. If SMS blocked → app tries Notification Listener
3. If Notification Listener not enabled → nothing blocks the app (silent fail)

User can manually trigger SMS scan from the Transactions page using the
existing "Scan SMS" button (already in your app).

---

## How bank balance is calculated

```
bankBalance  = initialBankBalance  + all bank income  - all bank expenses
cashBalance  = initialCashBalance  + cash income + ATM withdrawals - cash expenses
totalBalance = bankBalance + cashBalance
```

Set `initialBankBalance` / `initialCashBalance` in Setup → Starting Balances
(already exists in your app).

---

## Checking it works

Open Logcat in Android Studio and filter by `[AutoScan]`:

```
[AutoScan] Starting startup auto-scan...
[AutoScan] Found notifications: 12
[AutoScan] Found SMS messages: 34
[AutoScan] 8 parsed, 5 new unique transactions
[FinanceContext] Auto-imported 5 SMS transactions
```
