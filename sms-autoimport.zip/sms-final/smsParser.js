// ─────────────────────────────────────────────────────────────
//  smsParser.js  — Exact bank SMS parser from your APK bundle
// ─────────────────────────────────────────────────────────────

const DEBIT_PATTERNS = [
  /(?:rs\.?|inr|₹)\s*([\d,]+(?:\.\d{1,2})?)\s*(?:has\s+been\s+)?(?:debited|spent|withdrawn|transferred|paid|deducted|sent)/i,
  /(?:debited|spent|paid|withdrawn|deducted|sent)\s*(?:for|by|of)?\s*(?:rs\.?|inr|₹)\s*([\d,]+(?:\.\d{1,2})?)/i,
  /sent\s*(?:rs\.?|inr|₹)\s*([\d,]+(?:\.\d{1,2})?)\s*to/i,
];

const CREDIT_PATTERNS = [
  /(?:rs\.?|inr|₹)\s*([\d,]+(?:\.\d{1,2})?)\s*(?:has\s+been\s+)?(?:credited|deposited|received)/i,
  /(?:credited|deposited|received)\s*(?:for|by|of)?\s*(?:rs\.?|inr|₹)\s*([\d,]+(?:\.\d{1,2})?)/i,
  /(?:sent|transferred|paid)\s+you\s*(?:rs\.?|inr|₹)\s*([\d,]+(?:\.\d{1,2})?)/i,
];

const MERCHANT_PATTERN =
  /(?:at|to|towards|vpa|info|transfer\s+to|paid\s+to)\s+([a-zA-Z0-9\s\-_\.\*@/,\(\)]+?)(?:\s+(?:on|via|using|ref|info|balance|date)|[\.,]|\s*|$)/gi;

const MERCHANT_REF_PATTERN =
  /(?:merchant|ref|txn)\s+(?:name\s+)?([a-zA-Z0-9\s\-_\.\*@/,\(\)]{3,25})/gi;

function isValidMerchant(name) {
  if (!name) return false;
  const s = name.trim();
  if (s.length < 2) return false;
  const lower = s.toLowerCase();
  if (
    lower.includes("a/c") || lower.includes("acct") ||
    lower.includes("account") || lower.includes("card") ||
    lower.includes("ending")
  ) return false;
  const digits = s.replace(/\D/g, "");
  return !(digits.length > 0 && digits.length >= s.length * 0.7);
}

export function detectBankName(sms) {
  const t = sms.toLowerCase();
  if (t.includes("indian bank") || t.includes("ind bank") || t.includes("indianbank")) return "Indian Bank";
  if (t.includes("canara") || t.includes("cnrb")) return "Canara Bank";
  if (t.includes("sbi") || t.includes("state bank") || t.includes("yono")) return "SBI";
  if (t.includes("hdfc")) return "HDFC Bank";
  if (t.includes("icici")) return "ICICI Bank";
  if (t.includes("axis")) return "Axis Bank";
  if (t.includes("kotak")) return "Kotak Bank";
  if (t.includes("baroda") || t.includes("bob")) return "Bank of Baroda";
  if (t.includes("pnb") || t.includes("punjab national")) return "PNB";
  if (t.includes("paytm") || t.includes("ppbl")) return "Paytm Bank";
  if (t.includes("airtel") || t.includes("apbl")) return "Airtel Bank";
  if (t.includes("gpay") || t.includes("google pay")) return "GPay";
  if (t.includes("phonepe")) return "PhonePe";
  return "Bank Account";
}

export function extractAccountEnding(sms) {
  const patterns = [
    /(?:a\/c|acct|account|card|ending)\s*(?:ending)?\s*(?:in|with)?\s*([xX\*]*\d{3,4})/i,
    /(?:a\/c|acct|account|card)\s*(?:ending)?\s*(?:in|with)?\s*(\d{3,4})/i,
    /ending\s+([xX\*]*\d{3,4})/i,
    /ending\s+in\s+(\d{3,4})/i,
  ];
  for (const p of patterns) {
    const m = sms.match(p);
    if (m && m[1]) {
      const digits = m[1].replace(/\D/g, "");
      if (digits.length >= 3) return digits;
    }
  }
  return null;
}

export function parseSms(body, timestamp) {
  if (!body) return null;
  const lower = body.toLowerCase();

  if (
    lower.includes("failed") || lower.includes("declined") ||
    lower.includes("insufficient") || lower.includes("unsuccessful") ||
    lower.includes("rejected")
  ) return null;

  let amount = null;
  let type = null;
  let description = "Online Transaction";
  let paymentMode = "upi";

  for (const p of DEBIT_PATTERNS) {
    const m = body.match(p);
    if (m) {
      const val = m[1] || m[2];
      if (val) { amount = parseFloat(val.replace(/,/g, "")); type = "expense"; break; }
    }
  }

  if (!amount) {
    for (const p of CREDIT_PATTERNS) {
      const m = body.match(p);
      if (m) {
        const val = m[1] || m[2];
        if (val) { amount = parseFloat(val.replace(/,/g, "")); type = "income"; break; }
      }
    }
  }

  if (!amount || isNaN(amount)) return null;

  let merchant = null;
  const mm = [...body.matchAll(MERCHANT_PATTERN)];
  for (const m of mm) {
    if (m?.[1]) { const n = m[1].trim(); if (isValidMerchant(n)) { merchant = n; break; } }
  }
  if (!merchant) {
    const rm = [...body.matchAll(MERCHANT_REF_PATTERN)];
    for (const m of rm) {
      if (m?.[1]) { const n = m[1].trim(); if (isValidMerchant(n)) { merchant = n; break; } }
    }
  }

  if (merchant) {
    merchant = merchant.split("(")[0].trim();
    merchant = merchant.replace(/^vpa\s+/i, "");
    merchant = merchant.replace(/[.,\s]+$/, "").trim();
    description = merchant;
  }

  description = description.replace(/\s+/g, " ");
  if (description.length > 30) description = description.substring(0, 27) + "...";

  if (lower.includes("atm") || lower.includes("cash withdrawal")) {
    paymentMode = "cash"; description = "ATM Cash Withdrawal";
  } else if (lower.includes("card") || lower.includes("debitcard") || lower.includes("creditcard") || lower.includes("spent on your") || lower.includes("ending in")) {
    paymentMode = "card";
  } else if (lower.includes("netbanking") || lower.includes("internet banking") || lower.includes("imps") || lower.includes("neft") || lower.includes("rtgs")) {
    paymentMode = "netbanking";
  } else if (lower.includes("upi") || lower.includes("gpay") || lower.includes("phonepe") || lower.includes("paytm") || lower.includes("amazonpay")) {
    paymentMode = "upi";
  }

  return {
    amount,
    description,
    type,
    date: timestamp ? new Date(timestamp).toISOString() : new Date().toISOString(),
    paymentMode,
    bankName: detectBankName(body),
    accountEnding: extractAccountEnding(body),
    rawSms: body,
  };
}
