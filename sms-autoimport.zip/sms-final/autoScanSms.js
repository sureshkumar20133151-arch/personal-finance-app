// ─────────────────────────────────────────────────────────────────────────────
//  autoScanSms.js
//
//  Drop this file into your src/ folder.
//
//  What it does:
//   1. On app startup → auto-scans last 30 days of SMS + notifications
//   2. De-duplicates against existing transactions
//   3. Auto-assigns category based on description keywords
//   4. Returns new transactions ready to merge into your state
//
//  Your FinanceContext already calls f() and p() for this — this file
//  replaces those two functions with clean, named exports.
// ─────────────────────────────────────────────────────────────────────────────

import { registerPlugin } from "@capacitor/core";
import { parseSms } from "./smsParser";

const MessageReader       = registerPlugin("MessageReader");
const NotificationListener = registerPlugin("NotificationListener");

const SCAN_DAYS = 30;

// ─── Auto-assign category from description + type ────────────────────────────
export function autoCategory(description, type, categories = []) {
  const d = description.toLowerCase();
  const income  = categories.filter(c => c.type === "income");
  const expense = categories.filter(c => c.type === "expense");
  const firstExpense = expense[0]?.id || "";
  const firstIncome  = income[0]?.id  || "";

  if (type === "income") {
    if (d.includes("salary") || d.includes("salary credited")) {
      const cat = income.find(c => c.name.toLowerCase().includes("salary"));
      return cat ? cat.id : firstIncome;
    }
    const biz = income.find(c =>
      c.name.toLowerCase().includes("freelance") || c.name.toLowerCase().includes("business")
    );
    return biz ? biz.id : firstIncome;
  }

  // Expense keyword matching
  const expenseMap = [
    { keywords: ["zomato","swiggy","food","restaurant","chai","cafe","hotel"], catWords: ["food","dining","coffee"] },
    { keywords: ["petrol","fuel","uber","ola","travel","auto","cab","rapido"], catWords: ["transport","travel","fuel"] },
    { keywords: ["netflix","spotify","prime","movie","cinema","hotstar"],      catWords: ["entertainment","sub"] },
    { keywords: ["electricity","recharge","water","utilities","broadband","wifi","ebill"], catWords: ["utilities","bill"] },
    { keywords: ["amazon","flipkart","shop","myntra","meesho"],               catWords: ["shopping","clothes"] },
    { keywords: ["doctor","hospital","medicine","pharmacy","clinic"],         catWords: ["health","medical"] },
  ];

  for (const { keywords, catWords } of expenseMap) {
    if (keywords.some(k => d.includes(k))) {
      const cat = expense.find(c => catWords.some(w => c.name.toLowerCase().includes(w)));
      if (cat) return cat.id;
    }
  }

  return firstExpense;
}

// ─── Check if a parsed transaction already exists ────────────────────────────
function isDuplicate(existing = [], tx) {
  return existing.some(e =>
    e.date         === tx.date &&
    Math.abs(e.amount - tx.amount) < 0.01 &&
    e.type         === tx.type &&
    e.bankName     === tx.bankName &&
    e.accountEnding=== tx.accountEnding
  );
}

// ─── Main auto-scan — call this on app startup ────────────────────────────────
export async function autoScanTransactions(existingTransactions = []) {
  if (!(window.Capacitor?.isNativePlatform())) return [];

  const minDate = Date.now() - SCAN_DAYS * 24 * 60 * 60 * 1000;
  const parsed  = [];

  // Try Notification Listener
  try {
    const status = await NotificationListener.isListenerEnabled();
    if (status?.enabled) {
      const { notifications = [] } = await NotificationListener.getCapturedNotifications({
        minDate: String(minDate),
      });
      notifications.forEach(n => {
        const tx = parseSms(n.body, parseInt(n.date));
        if (tx) parsed.push(tx);
      });
    }
  } catch (e) {
    console.warn("[AutoScan] Notification listener failed:", e);
  }

  // Try SMS (if permission already granted — don't ask on startup)
  try {
    const perm = await MessageReader.checkPermissions();
    if (perm?.messages === "granted") {
      const { messages = [] } = await MessageReader.getMessages({ minDate, limit: 200 });
      messages.forEach(m => {
        const tx = parseSms(m.body, parseInt(m.date));
        if (tx) parsed.push(tx);
      });
    }
  } catch (e) {
    console.warn("[AutoScan] SMS check failed:", e);
  }

  if (parsed.length === 0) return [];

  // De-duplicate
  const newTxs = parsed.filter(tx => !isDuplicate(existingTransactions, tx));
  console.log(`[AutoScan] ${parsed.length} parsed, ${newTxs.length} new unique transactions`);
  return newTxs;
}

// ─── Foreground rescan — call this when app comes to foreground ───────────────
export async function rescanTransactions(existingTransactions = []) {
  return autoScanTransactions(existingTransactions);
}
