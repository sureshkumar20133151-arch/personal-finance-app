// ─────────────────────────────────────────────────────────────────────────────
//  FinanceContext.jsx  —  DROP-IN REPLACEMENT for your existing context
//
//  Changes from your original:
//   ✅ Auto-scans SMS + notifications on startup
//   ✅ Re-scans when app comes to foreground
//   ✅ Bank balance calculated from initialBankBalance + all transactions
//   ✅ bankBalance exposed in context (use it on Dashboard)
//   ✅ cashBalance exposed in context
//   ✅ totalBalance = bankBalance + cashBalance
//   ✅ addTransactions() exposed for manual SMS scan modal
//
//  Everything else (categories, loans, recurring, Firebase sync) unchanged.
// ─────────────────────────────────────────────────────────────────────────────

import React, { createContext, useContext, useState, useCallback, useEffect, useRef } from "react";
import { registerPlugin }    from "@capacitor/core";
import { doc, setDoc, onSnapshot } from "firebase/firestore";
import { db }                from "./firebase";          // ← your firebase.js path
import { useAuth }           from "./AuthContext";       // ← your auth context path
import { autoScanTransactions, autoCategory } from "./autoScanSms";
import { v4 as uuidv4 }     from "uuid";

const App = registerPlugin("App");

// ─── Default data ─────────────────────────────────────────────────────────────
const DEFAULT_CATEGORIES = [
  { id: "1",  name: "Salary",         type: "income",  color: "#10b981", icon: "Wallet",      budget: 0   },
  { id: "2",  name: "Freelance",      type: "income",  color: "#3b82f6", icon: "Laptop",      budget: 0   },
  { id: "3",  name: "Food",           type: "expense", color: "#f59e0b", icon: "Utensils",    budget: 500 },
  { id: "4",  name: "Transport",      type: "expense", color: "#ef4444", icon: "Car",         budget: 200 },
  { id: "5",  name: "Utilities",      type: "expense", color: "#6366f1", icon: "Zap",         budget: 150 },
  { id: "6",  name: "Emergency Fund", type: "savings", color: "#06b6d4", icon: "ShieldCheck", budget: 0   },
  { id: "7",  name: "Credit Card",    type: "debt",    color: "#f97316", icon: "CreditCard",  budget: 0   },
  { id: "8",  name: "Clothes",        type: "expense", color: "#ec4899", icon: "ShoppingBag", budget: 100 },
  { id: "9",  name: "Coffee",         type: "expense", color: "#8b5cf6", icon: "Coffee",      budget: 50  },
  { id: "10", name: "Beauty",         type: "expense", color: "#f472b6", icon: "Sparkles",    budget: 0   },
  { id: "11", name: "Entertainment",  type: "expense", color: "#14b8a6", icon: "Clapperboard",budget: 100 },
];

const DEFAULT_STATE = {
  categories:         DEFAULT_CATEGORIES,
  transactions:       [],
  currency:           { code: "INR", symbol: "₹", locale: "en-IN", name: "Indian Rupee" },
  theme:              { mode: "light", accent: "blue" },
  subscription:       "free",
  recurring:          [],
  loans:              [],
  monthlyBudget:      50000,
  lastProcessedMonth: "",
  salaryDate:         1,
  initialBankBalance: 0,
  initialCashBalance: 0,
};

const STORAGE_KEY = "fintrack_data";

// ─── Context ──────────────────────────────────────────────────────────────────
const FinanceContext = createContext(undefined);

export function FinanceProvider({ children }) {
  const { currentUser } = useAuth();

  const [state, setState] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    try { return saved ? { ...DEFAULT_STATE, ...JSON.parse(saved) } : DEFAULT_STATE; }
    catch { return DEFAULT_STATE; }
  });

  const [loading, setLoading] = useState(true);

  // ─── Persist ──────────────────────────────────────────────────────────────
  const persistDebounce = useRef(null);

  const saveImmediate = useCallback((data) => {
    setState(data);
    if (currentUser && !currentUser.isAnonymous) {
      setDoc(doc(db, "users", currentUser.uid), data, { merge: true })
        .catch(e => console.error("Firebase save failed", e));
    } else {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    }
  }, [currentUser]);

  const saveDebounced = useCallback((data) => {
    setState(data);
    if (currentUser && !currentUser.isAnonymous) {
      if (persistDebounce.current) clearTimeout(persistDebounce.current);
      persistDebounce.current = setTimeout(() => {
        setDoc(doc(db, "users", currentUser.uid), data, { merge: true })
          .catch(e => console.error("Firebase save failed", e));
      }, 800);
    } else {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    }
  }, [currentUser]);

  // ─── Load from Firebase / localStorage ───────────────────────────────────
  useEffect(() => {
    let cancelled = false;

    const boot = async (loadedState) => {
      if (!cancelled) {
        // Run auto SMS scan immediately after load
        const newTxs = await autoScanTransactions(loadedState.transactions || []);
        if (newTxs.length > 0 && !cancelled) {
          console.log(`[FinanceContext] Auto-imported ${newTxs.length} SMS transactions`);
          const withCategory = newTxs.map(tx => ({
            ...tx,
            id:         uuidv4(),
            categoryId: autoCategory(tx.description, tx.type, loadedState.categories || DEFAULT_CATEGORIES),
          }));
          const merged = {
            ...loadedState,
            transactions: [...(loadedState.transactions || []), ...withCategory],
          };
          saveImmediate(merged);
          setState(merged);
        } else {
          setState(loadedState);
        }
        setLoading(false);
      }
    };

    if (!currentUser || currentUser.isAnonymous) {
      const saved = localStorage.getItem(STORAGE_KEY);
      let data = DEFAULT_STATE;
      try { if (saved) data = { ...DEFAULT_STATE, ...JSON.parse(saved) }; }
      catch (e) { console.warn("LocalStorage parse failed", e); }
      boot(data);
      return;
    }

    const unsub = onSnapshot(doc(db, "users", currentUser.uid),
      (snap) => {
        if (snap.exists()) {
          const data = {
            ...DEFAULT_STATE,
            ...snap.data(),
            theme:    snap.data().theme    || DEFAULT_STATE.theme,
            currency: snap.data().currency || DEFAULT_STATE.currency,
          };
          boot(data);
        } else {
          setDoc(doc(db, "users", currentUser.uid), DEFAULT_STATE).then(() => boot(DEFAULT_STATE));
        }
      },
      (err) => { console.error("Firebase snapshot error", err); setLoading(false); }
    );

    return () => { cancelled = true; unsub(); };
  }, [currentUser]);

  // ─── Foreground rescan ────────────────────────────────────────────────────
  const rescanLock = useRef(false);
  const stateRef   = useRef(state);
  useEffect(() => { stateRef.current = state; }, [state]);

  const rescanTransactions = useCallback(async () => {
    if (!window.Capacitor?.isNativePlatform() || rescanLock.current) return 0;
    rescanLock.current = true;
    try {
      const current = stateRef.current;
      const newTxs  = await autoScanTransactions(current.transactions || []);
      if (newTxs.length > 0) {
        const withCategory = newTxs.map(tx => ({
          ...tx,
          id:         uuidv4(),
          categoryId: autoCategory(tx.description, tx.type, current.categories || DEFAULT_CATEGORIES),
        }));
        const merged = {
          ...current,
          transactions: [...(current.transactions || []), ...withCategory],
        };
        saveImmediate(merged);
        return newTxs.length;
      }
      return 0;
    } catch (e) {
      console.error("[Rescan] Error:", e);
      return 0;
    } finally {
      rescanLock.current = false;
    }
  }, [saveImmediate]);

  // Re-scan when app comes to foreground
  useEffect(() => {
    if (!window.Capacitor?.isNativePlatform()) return;
    let listener;
    App.addListener("appStateChange", ({ isActive }) => {
      if (isActive) rescanTransactions();
    }).then(l => { listener = l; });
    return () => { listener?.remove(); };
  }, [rescanTransactions]);

  // ─── Computed balances ────────────────────────────────────────────────────
  const bankBalance = React.useMemo(() => {
    const allTx = state.transactions || [];
    const bankIn  = allTx.filter(t => t.type === "income" && t.paymentMode !== "cash");
    const bankOut = allTx.filter(t =>
      (t.type === "expense" || t.type === "debt") &&
      (t.paymentMode !== "cash" || t.description?.toLowerCase().includes("atm") || t.description?.toLowerCase().includes("cash withdrawal"))
    );
    const inflow  = bankIn.reduce((s, t) => s + t.amount, 0);
    const outflow = bankOut.reduce((s, t) => s + t.amount, 0);
    return (state.initialBankBalance || 0) + inflow - outflow;
  }, [state.transactions, state.initialBankBalance]);

  const cashBalance = React.useMemo(() => {
    const allTx   = state.transactions || [];
    const cashIn  = allTx.filter(t => t.type === "income" && t.paymentMode === "cash");
    const atmOut  = allTx.filter(t =>
      t.type === "expense" &&
      (t.description?.toLowerCase().includes("atm") || t.description?.toLowerCase().includes("cash withdrawal"))
    );
    const cashOut = allTx.filter(t =>
      (t.type === "expense" || t.type === "debt") &&
      t.paymentMode === "cash" &&
      !t.description?.toLowerCase().includes("atm") &&
      !t.description?.toLowerCase().includes("cash withdrawal")
    );
    const inflow  = cashIn.reduce((s, t) => s + t.amount, 0) + atmOut.reduce((s, t) => s + t.amount, 0);
    const outflow = cashOut.reduce((s, t) => s + t.amount, 0);
    return (state.initialCashBalance || 0) + inflow - outflow;
  }, [state.transactions, state.initialCashBalance]);

  // ─── Per-bank balances (for dashboard cards) ──────────────────────────────
  const bankAccountBalances = React.useMemo(() => {
    const map = {};
    (state.transactions || []).forEach(t => {
      if (t.bankName && t.accountEnding) {
        const key = `${t.bankName}_${t.accountEnding}`;
        if (!map[key]) map[key] = { bankName: t.bankName, accountEnding: t.accountEnding, balance: 0, transactionCount: 0 };
        if (t.type === "income") map[key].balance += t.amount;
        else if (t.type === "expense" || t.type === "debt") map[key].balance -= t.amount;
        map[key].transactionCount++;
      }
    });
    return Object.values(map);
  }, [state.transactions]);

  // ─── formatMoney ─────────────────────────────────────────────────────────
  const formatMoney = useCallback((amount) =>
    new Intl.NumberFormat(state.currency?.locale || "en-IN", {
      style: "currency", currency: state.currency?.code || "INR",
      maximumFractionDigits: 0, minimumFractionDigits: 0,
    }).format(amount), [state.currency]);

  // ─── CRUD ────────────────────────────────────────────────────────────────
  const addTransaction = useCallback((tx) => {
    const next = {
      ...state,
      transactions: [...state.transactions, { ...tx, id: uuidv4(), date: tx.date || new Date().toISOString() }],
    };
    saveDebounced(next);
  }, [state, saveDebounced]);

  const addTransactions = useCallback((txList) => {
    const next = {
      ...state,
      transactions: [
        ...state.transactions,
        ...txList.map(tx => ({ ...tx, id: uuidv4(), date: tx.date || new Date().toISOString() })),
      ],
    };
    saveImmediate(next);
  }, [state, saveImmediate]);

  const updateTransaction = useCallback((id, updates) => {
    const next = { ...state, transactions: state.transactions.map(t => t.id === id ? { ...t, ...updates } : t) };
    saveDebounced(next);
  }, [state, saveDebounced]);

  const deleteTransaction = useCallback((id) => {
    const next = { ...state, transactions: state.transactions.filter(t => t.id !== id) };
    saveDebounced(next);
  }, [state, saveDebounced]);

  const addCategory    = (cat)    => saveImmediate({ ...state, categories: [...state.categories, { ...cat, id: uuidv4() }] });
  const deleteCategory = (id)     => saveImmediate({ ...state, categories: state.categories.filter(c => c.id !== id) });
  const updateCategory = (id, up) => saveImmediate({ ...state, categories: state.categories.map(c => c.id === id ? { ...c, ...up } : c) });

  const updateCurrency    = (c)    => saveImmediate({ ...state, currency: c });
  const updateTheme       = (t)    => saveImmediate({ ...state, theme: { ...state.theme, ...t } });
  const updateSubscription= (s)    => saveImmediate({ ...state, subscription: s });
  const updateBudget      = (b)    => saveImmediate({ ...state, monthlyBudget: parseFloat(b) });
  const updateSalaryDate  = (d)    => saveImmediate({ ...state, salaryDate: parseInt(d) });

  const updateStartingBalances = (bank, cash) =>
    saveImmediate({ ...state, initialBankBalance: parseFloat(bank) || 0, initialCashBalance: parseFloat(cash) || 0 });

  const addRecurring    = (r)  => saveImmediate({ ...state, recurring: [...(state.recurring || []), { ...r, id: uuidv4(), active: true }] });
  const deleteRecurring = (id) => saveImmediate({ ...state, recurring: (state.recurring || []).filter(r => r.id !== id) });
  const addLoan         = (l)  => saveImmediate({ ...state, loans: [...(state.loans || []), { ...l, id: uuidv4() }] });
  const deleteLoan      = (id) => saveImmediate({ ...state, loans: (state.loans || []).filter(l => l.id !== id) });

  const clearData = () => {
    const fresh = { ...DEFAULT_STATE, theme: state.theme, currency: state.currency };
    if (currentUser && !currentUser.isAnonymous) {
      setDoc(doc(db, "users", currentUser.uid), fresh).then(() => window.location.reload());
    } else {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh));
      setState(fresh);
      window.location.reload();
    }
  };

  // Apply theme
  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove("light", "dark");
    if (state.theme?.mode === "system") {
      root.classList.add(window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
    } else if (state.theme?.mode) {
      root.classList.add(state.theme.mode);
    }
    if (state.theme?.accent) root.setAttribute("data-theme", state.theme.accent);
  }, [state.theme]);

  const value = {
    // data
    categories:           state.categories   || [],
    transactions:         state.transactions || [],
    currency:             state.currency,
    theme:                state.theme,
    subscription:         state.subscription,
    recurring:            state.recurring     || [],
    loans:                state.loans         || [],
    monthlyBudget:        state.monthlyBudget || 50000,
    salaryDate:           state.salaryDate    || 1,
    initialBankBalance:   state.initialBankBalance || 0,
    initialCashBalance:   state.initialCashBalance || 0,
    loading,

    // ✅ NEW — use these on Dashboard
    bankBalance,
    cashBalance,
    totalBalance: bankBalance + cashBalance,
    bankAccountBalances,   // per-bank breakdown array

    // helpers
    formatMoney,
    rescanTransactions,

    // CRUD
    addCategory, deleteCategory, updateCategory,
    addTransaction, addTransactions,
    updateTransaction, deleteTransaction,
    updateCurrency, updateTheme, updateSubscription,
    updateBudget, updateSalaryDate, updateStartingBalances,
    addRecurringTransaction:    addRecurring,
    deleteRecurringTransaction: deleteRecurring,
    addLoan, deleteLoan,
    clearData,
  };

  return <FinanceContext.Provider value={value}>{children}</FinanceContext.Provider>;
}

export function useFinanceData() {
  const ctx = useContext(FinanceContext);
  if (!ctx) throw new Error("useFinanceData must be inside FinanceProvider");
  return ctx;
}
